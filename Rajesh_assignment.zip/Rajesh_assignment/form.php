<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
     <title>form</title>
     <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link rel="stylesheet" href="./index.css">
</head>
<body>
    
      <div class="container"> 
    <form action="./action.php" method="POST" enctype="multipart/form-data" class="needs-validation" novalidate>
        <div class="mb-3">
          <label for="full-name" class="form-label">Full Name:</label>
          <input type="text" class="form-control" id="full-name" name="fname" required>
          <div class="invalid-feedback">Please enter your full name.</div>
        </div>
        
        <div class="mb-3">
          <label for="resume" class="form-label">Upload Resume:</label>
          <input type="file" class="form-control" id="resume" name="uploadresume" accept=".pdf,.doc,.docx" required>
          <div class="invalid-feedback">Please upload your resume in PDF or Word format.</div>
        </div>
        
        <div class="mb-3">
          <label class="form-label">Technology:</label>
          <div class="form-check">
            <input class="form-check-input" type="checkbox" id="technology-html" name="technology" value="HTML">
            <label class="form-check-label" for="technology-html">HTML</label>
          </div>
          <div class="form-check">
            <input class="form-check-input" type="checkbox" id="technology-css" name="technology" value="CSS">
            <label class="form-check-label" for="technology-css">CSS</label>
          </div>
          <div class="form-check">
            <input class="form-check-input" type="checkbox" id="technology-js" name="technology" value="JavaScript">
            <label class="form-check-label" for="technology-js">JavaScript</label>
          </div>
        </div>
        
        <button type="submit" class="btn btn-primary" name="submit">Submit</button>
      </form>
    </div> 
      
      
      
    
</body>
</html>