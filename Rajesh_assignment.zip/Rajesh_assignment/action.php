<?php
require_once("./config.php");

if (isset($_POST['submit'])) {
    $fullname = trim($_POST['full_name']);
    $resume = trim($_POST['upload_resume']);
    $technology = isset($_POST['technology']) ? implode(", ", $_POST['technology']) : '';

    $folder = "uploads/";

    $resume_file = $_FILES['resume']['name'];
    $file = $_FILES['resume']['tmp_name'];

    $path = $folder . $resume_file;
    $file_name_array = explode(".", $resume_file);
    $extension = end($file_name_array);
    $new_resume_name = 'resume_' . rand() . '.' . $extension;

    if ($file != '') {
        move_uploaded_file($file, $folder . $new_resume_name);
    }

    $sql = "INSERT INTO resource (full_name, upload_resume, technology) 
            VALUES (:full_name, :upload_resume, :technology)";

    $stmt = $db->prepare($sql);
    $stmt->bindParam(':full_name', $fullname, PDO::PARAM_STR);
    $stmt->bindParam(':upload_resume', $new_resume_name, PDO::PARAM_STR);
    $stmt->bindParam(':technology', $technology, PDO::PARAM_STR);
    $stmt->execute();
    $last_id = $db->lastInsertId();

    if ($last_id != '') {
        header("location:preview.php?id=" . $last_id);
    } else {
        echo 'Something went wrong';
    }
}
?>
